import module_manager
module_manager.review()

import tkinter as tk

from tkinter import *

from tkinter.ttk import *

from cmu_112_graphics import *

from Ter

class GFG:
    def __init__(self, master = None):
        self.master = master

        self.x = 1
        self.y = 0

        self.canvas = Canvas(master)
        self.rectangle(self.canvas.create_rectangle(5, 5, 25, 25, fill = "black"))




class Background(object):
    def __init__(self, color):
        self.color = color

startTheGame = Background("Green")
JustBeforeTheGame = Background("Green")
duringTheGame = Background("dim gray")

class Title(object):
    def __init__(self, content, fontColor, fontSize):
        self.content = content
        self.fontColor = fontColor
        self.fontSize = fontSize
        self.location = -1

firstTitle = Title("Type 'exiciting' to get started!", "White", "Purisa 50 bold")
title1 = Title("Woodboy", "sienna4", "Purisa 50 bold")
title2 = Title("&", "black", "Purisa 50 bold")
title3 = Title("Metalgirl", "gray50", "Purisa 50 bold")
subtitle = Title("Do you want some gold?", "White", "Purisa 30 bold")


class Button(Title):
    def __init__(self, ovalColor, content, outline, fontSize, fontColor):
        super().__init__(content, fontSize, fontColor)
        self.color = ovalColor
        self.outline = outline

choiceYes = Button("red", "YES", "white", "white", "Purisa 50 bold")
choiceNo = Button("blue", "NO", "white", "white", "Purisa 50 bold")

class Door(object):
    def __init__(self, name, color):
        self.name = name
        self.startColor = color
        self.endColor = "Gold" #for both players

    '''
    If both players reach the proper doors with all the tokens collected, then 
    move on to the next level (app.level += 1)
    '''

class Platform(object):
    def __init__(self, color):
        self.color = color

floor = Platform("dark gray")

class Gem(object):
    def __init__(self, color, size):
        self.color = color
        self.size = size

coin1 = Gem("goldenrod1", 20)
coin2 = Gem("goldenrod1", 20)


class Obstacles(object):
    def __init__(self, color):
        self.color = color
        self.location = []

switch = Obstacles("red")
bar = Obstacles("green")
hangingWood = Obstacles("brown")
Lightning = Obstacles("yellow")
Water = Obstacles("Light blue")


def appStarted(app):
    app.margin = min(app.width, app.height) // 50
    app.direction = (0, 1)
    app.row = 4 #start with three platforms (easy level)
    app.firstPage = True #check if the game is on the first page
    app.start = False
    app.counter = 1
    app.positionOfNo = 42
    app.positionOfYes = 42
    app.nextToStart = False
    app.coin1CX = 0
    app.coin2CX = 0
    app.buttonYesLocation = (app.width // 4 , app.height//2 + 2 * app.margin)
    app.buttonNoLocation = (app.width - 15 * app.margin, app.height//2 + 2 * app.margin)
    app.door1Location = (app.width // 8 - app.margin, app.height - 6 * app.margin)
    app.door2Location = []
    
    #counting the level
    app.level = 1

def doMove(app):
    pass

def endTheLevel(app):
    app.level += 1

def mousePressed(app, event):
    if isWithinRangeYes(app, event.x, event.y):
        app.nextToStart = True
    elif isWithinRangeNo(app, event.x, event.y):
        app.start = True ## need to fix this

def isWithinRangeYes(app, x, y):
    buttonR = min(app.width, app.height) // 10
    curX, curY = app.buttonYesLocation
    return ((curX - x)**2 + (curY - y)**2)**0.5 <= buttonR

def isWithinRangeNo(app, x, y):
    buttonR = min(app.width, app.height) // 10
    curX, curY = app.buttonNoLocation
    return ((curX - x)**2 + (curY - y)**2)**0.5 <= buttonR

def keyPressed(app,event):
    if app.firstPage:
        if event.key == "g":
            app.firstPage = False
    #for character 1
    if event.key == "Up":
        app.direction = (1, 0)
    elif event.key == "Down":
        app.direction = (-1, 0)
    elif event.key == "Left":
        app.direction = (0, -1)
    elif event.key == "Right":
        app.direction = (0, 1)
    #for character 2
    if event.key == "w":
        app.direction = (1, 0)
    elif event.key == "s":
        app.direction = (-1, 0)
    elif event.key == "a":
        app.direction = (0, -1)
    elif event.key == "d":
        app.direction = (0, 1)

def drawCharacter(app, canvas):
    #player 1: Woodboy
    boyFaceR = app.margin 
    (x , y)  = app.door1Location
    newX, newY = x * 1.5, y
    #face
    canvas.create_rectangle(newX - boyFaceR,  y -boyFaceR, newX+ boyFaceR, 
                            y + boyFaceR, width = 1, fill = woodboy.color, outline = woodboy.contour)
    #body
    canvas.create_rectangle(newX - boyFaceR,  y + boyFaceR, newX + boyFaceR, y + boyFaceR * 3, 
                        outline = woodboy.contour, fill = woodboy.color, width = 2)
    
    #legs
    canvas.create_rectangle(newX - boyFaceR, y + boyFaceR * 3,newX  - boyFaceR // 3 , y + boyFaceR * 5,
                            outline = woodboy.contour, fill = woodboy.color, width = 2)
    canvas.create_rectangle(newX  + boyFaceR // 5, y + boyFaceR * 3,newX  + boyFaceR, y + boyFaceR * 5,
                            outline = woodboy.contour, fill = woodboy.color, width = 2)
    
    #leaves on the top of the character's head
    canvas.create_line(newX, y -boyFaceR, newX, y - 2 * boyFaceR)
    canvas.create_line(newX, y - boyFaceR * 1.5, newX - app.margin // 3, y - boyFaceR * 2, fill = "green")
    canvas.create_line(newX, y - boyFaceR * 1.2, newX + app.margin // 4, y - boyFaceR * 1.5, fill = "green")
    
    #eyes
    eyeX, eyeY = newX - app.margin // 2, newY - app.margin // 3
    eyeR = boyFaceR // 8
    canvas.create_oval(eyeX - eyeR, eyeY - eyeR, eyeX + eyeR, eyeY + eyeR, fill = "black")
    canvas.create_oval(newX + app.margin // 2 - eyeR, eyeY - eyeR, newX + app.margin // 2+ eyeR, eyeY + eyeR, fill = "black")
    
    #nose
    noseR = boyFaceR // 7
    canvas.create_rectangle(newX - noseR, newY - noseR, newX + noseR, newY + noseR, fill = "black")
    
    #arms

    canvas.create_polygon(newX + boyFaceR, y + boyFaceR, newX + boyFaceR, y + boyFaceR * 2,
                        newX + boyFaceR * 2, y, newX + boyFaceR * 2, y + boyFaceR * 4, fill = woodboy.color, outline = woodboy.contour)
    #player 2: Metalgirl




def drawPlatform(app, canvas):
    margin = min(app.width, app.height) // 50
    pHeight = app.height // app.row
    for row in range(app.row+1):
        canvas.create_rectangle(margin, pHeight * row + margin,
                app.width - margin, pHeight * (row+1) + margin, width = 3)
        canvas.create_rectangle(margin, pHeight * (row+1) + margin,
                            app.width - margin, pHeight* (row+1) + 2 * margin,
                                            fill = "gray", width = 3)

    #the top platform that has a door for characters to get through
    canvas.create_rectangle(app.width // 2, pHeight - margin,
                    app.width - 20 * margin, pHeight - margin, width = 10)
    canvas.create_rectangle(app.width // 3, pHeight - margin,
                    app.width // 2 - 3 * margin,pHeight - margin, width = 10)

def drawDoor(app, canvas):
    margin = min(app.width, app.height) // 50
    pHeight = app.height // app.row

    #player 1 Door
    xLocation = app.width // 8
    yLocation = app.height - 10 * margin
    d = yLocation // 70
    doorxLocation = xLocation - margin
    dooryLocation = yLocation + 4 * margin
    canvas.create_rectangle(margin, yLocation,
            xLocation, app.height - margin, fill = "brown", width = 2)
    canvas.create_arc(margin, yLocation, xLocation, yLocation * 1.1,
                outline = "black", style = tk.ARC, extent = 180, width = 2)
    canvas.create_oval(doorxLocation - d, dooryLocation - d,
                    doorxLocation + d, dooryLocation + d, fill = "black")

    #player 1's final door
    canvas.create_rectangle(app.width // 3, 3 * margin,
        app.width // 2 - 3 * margin, pHeight - margin, fill = "gold", width = 2)
    canvas.create_oval(app.width // 2 - 4 * margin - d, 7 * margin - d,
            app.width // 2  - 4 * margin + d, 7 * margin + d, fill = "black")
    #player 2's door
    x2Location = app.width - xLocation
    doorx2Location = x2Location + margin
    canvas.create_rectangle(x2Location, yLocation, app.width - margin,
                    app.height - margin, fill = "azure3", width = 2)
    canvas.create_arc(x2Location, yLocation, app.width - margin,
    yLocation * 1.1, outline = "black", style = tk.ARC, extent = 180, width = 2)
    canvas.create_oval(doorx2Location - d, dooryLocation - d,
                doorx2Location + d, dooryLocation + d, fill = "black")


    #player 2's final door
    canvas.create_rectangle(app.width // 2, 3 * margin, app.width - 20 * margin,
                            pHeight - margin, fill = "gold", width = 2)
    canvas.create_oval(app.width // 2 + margin - d, 7 * margin - d,
            app.width // 2  + margin + d, 7 * margin + d, fill = "black")

def drawIntro(app, canvas):
    canvas.create_rectangle(0, 0, app.width, app.height, fill = startTheGame.color)
            #button for yes or no
    canvas.create_text(app.width//2, app.height//3,
                        text = subtitle.content,
                font = subtitle.fontSize, fill = subtitle.fontColor)
    buttonR = min(app.width, app.height) // 10
    buttonYesLocationX = app.width // 4
    buttonYesLocationY = app.height//2 + 2 * app.margin
    buttonNoLocationX = app.width - 15 * app.margin
    buttonNoLocationY = app.height//2 + 2 *app.margin
    canvas.create_oval(buttonYesLocationX - buttonR, buttonYesLocationY - buttonR,
                        buttonYesLocationX + buttonR, buttonYesLocationY+ buttonR,
                                    fill = choiceYes.color,
                            outline = choiceYes.outline, width = 3)
    canvas.create_oval( buttonNoLocationX - buttonR, buttonNoLocationY  - buttonR,
                        buttonNoLocationX + buttonR, buttonNoLocationY + buttonR, 
                            fill = choiceNo.color,
                            outline = choiceNo.outline, width = 3)
    canvas.create_text(buttonNoLocationX, buttonNoLocationY, 
            fill = choiceNo.fontColor, text = choiceNo.content)
    canvas.create_text(buttonYesLocationX, buttonYesLocationY, 
            fill = choiceYes.fontColor, text = choiceYes.content)

    #dropping coins 
    
    canvas.create_oval(app.width//2 - 15 * app.margin - coin1.size, 
                    app.height//3 - coin1.size, app.width//2 - 15 * app.margin + coin1.size,
                        app.height//3 + coin1.size, fill = coin1.color)
    canvas.create_oval(app.width - 10 * app.margin - coin2.size, app.height//3 - coin2.size, 
                app.width - 10 * app.margin + coin2.size, app.height//3 + coin2.size, fill = coin2.color)

def redrawAll(app, canvas):
    margin = min(app.width, app.height) // 50
    if app.firstPage:
        canvas.create_rectangle(0, 0, app.width, app.height, fill = startTheGame.color)
        canvas.create_text(app.width//2 - margin * 9, app.height//10, text = title1.content, underline = True,
                            font = title1.fontSize, fill = title1.fontColor)
        canvas.create_text(app.width//2, app.height//10, text = title2.content,
                            font = title2.fontSize, fill = title2.fontColor)
        canvas.create_text(app.width//2 + 9 * margin, app.height//10, text = title3.content, underline = True,
                            font = title3.fontSize, fill = title3.fontColor)
        canvas.create_text(app.width//2, app.height//2, text = firstTitle.content, 
                        fill = firstTitle.fontColor, font = firstTitle.fontSize)
    else:
        if not app.nextToStart:
            drawIntro(app, canvas)
           
        elif app.nextToStart:

            canvas.create_rectangle(0, 0, app.width, app.height, fill = duringTheGame.color)

            canvas.create_rectangle(margin, margin, app.width-margin, app.height-margin,
                                    fill = "Navajo white3",outline = "black")
            drawPlatform(app, canvas)
            drawDoor(app, canvas)
            drawCharacter(app, canvas)


runApp(width = 800, height = 800)

