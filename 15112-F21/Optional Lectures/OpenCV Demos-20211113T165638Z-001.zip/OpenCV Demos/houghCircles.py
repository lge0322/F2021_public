import cv2
import numpy as np



def houghCircles(img):
    img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    img = cv2.medianBlur(img,5) # apply slight blur to reduce noise
    cimg = cv2.cvtColor(img,cv2.COLOR_GRAY2BGR) # change to greyscale

    circles = cv2.HoughCircles(img,cv2.HOUGH_GRADIENT,1,20,
                                param1=75,param2=28,minRadius=0,maxRadius=0)
                            # tune these params ^
    circles = np.uint16(np.around(circles))
    for c in circles[0,:]:
        # draw the outer circle
        cv2.circle(cimg,(c[0],c[1]),c[2],(0,255,0),2)
        # draw the center of the circle
        cv2.circle(cimg,(c[0],c[1]),2,(0,0,255),3)

    return cimg

def testHoughCircles():
    img = cv2.imread('coins.jpg') # read image  

    cimg = houghCircles(img)

    cv2.imshow('detected circles',cimg)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# testHoughCircles()